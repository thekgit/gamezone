import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { assertAdmin } from "@/lib/assertAdmin";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET() {
  try {
    if (!assertAdmin()) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const admin = supabaseAdmin();

    const { data, error } = await admin
      .from("sessions")
      .select(
        `
        id,
        created_at,
        status,
        players,
        started_at,
        ended_at,
        ends_at,
        start_time,
        end_time,
        visitor_name,
        visitor_phone,
        visitor_email,
        games:game_id ( name )
      `
      )
      .order("created_at", { ascending: false })
      .limit(9999);

    if (error) return NextResponse.json({ error: error.message }, { status: 500 });

    const rows = (data || []).map((s: any) => ({
      id: s.id,
      created_at: s.created_at,

      full_name: s.visitor_name ?? null,
      phone: s.visitor_phone ?? null,
      email: s.visitor_email ?? null,

      game_name: s?.games?.name ?? null,

      slot_start: s.started_at ?? s.start_time ?? null,
      slot_end: s.ends_at ?? s.end_time ?? null,

      // ✅ UI field: exact QR scan time
      exit_time: s.ended_at ?? null,

      status: s.status ?? null,
      players: s.players ?? null,
    }));

    return NextResponse.json({ rows });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Server error" }, { status: 500 });
  }
}