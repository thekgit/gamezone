import AdminDashboardClient from "./ui/AdminDashboardClient";

export default function DashboardPage() {
  return <AdminDashboardClient />;
}